
import React, { useCallback, useState } from 'react';
import { THAI_LABELS } from '../constants';

interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
  disabled?: boolean;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, disabled }) => {
  const [dragActive, setDragActive] = useState(false);

  const handleFileChange = useCallback((files: FileList | null) => {
    if (files && files[0]) {
      const file = files[0];
      if (['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        onImageUpload(file);
      } else {
        alert(THAI_LABELS.ERROR_FILE_TYPE);
      }
    }
  }, [onImageUpload]);

  const handleDrag = useCallback((e: React.DragEvent<HTMLLabelElement>) => { // Changed type here
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLLabelElement>) => { // Changed type here
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files);
    }
  }, [handleFileChange]);

  const onButtonClick = (e: React.MouseEvent<HTMLInputElement>) => {
    (e.target as HTMLInputElement).value = ''; 
  };
  
  return (
    <div className="space-y-4">
        <label
            htmlFor="image-upload"
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer transition-colors
                        ${disabled ? 'bg-gray-700 cursor-not-allowed' : 
                        dragActive ? 'border-sky-500 bg-gray-700' : 'border-gray-600 hover:border-sky-400 bg-gray-700 hover:bg-gray-600'}`}
        >
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <CloudUploadIcon className={`w-10 h-10 mb-3 ${dragActive ? 'text-sky-400' : 'text-gray-400'}`} />
                <p className={`mb-2 text-sm ${dragActive ? 'text-sky-300' : 'text-gray-400'}`}>
                    <span className="font-semibold">{THAI_LABELS.UPLOAD_PROMPT.split(' หรือ ')[0]}</span> หรือ {THAI_LABELS.UPLOAD_PROMPT.split(' หรือ ')[1]}
                </p>
                <p className={`text-xs ${dragActive ? 'text-sky-400' : 'text-gray-500'}`}>JPG, PNG, WEBP</p>
            </div>
            <input
                id="image-upload"
                type="file"
                className="hidden"
                accept="image/jpeg,image/png,image/webp"
                onChange={(e) => handleFileChange(e.target.files)}
                onClick={onButtonClick}
                disabled={disabled}
            />
        </label>
    </div>
  );
};

const CloudUploadIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75Z" />
    </svg>
);
