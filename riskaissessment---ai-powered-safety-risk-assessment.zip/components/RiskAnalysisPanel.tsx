
import React, { useState } from 'react'; // useMemo removed as sorting is now done by parent
import type { AnalyzedRisk } from '../types';
import { RiskLevel } from '../types';
import { RiskAssessmentTable } from './RiskAssessmentTable';
import { THAI_LABELS, RISK_LEVEL_COLORS } from '../constants'; // RISK_LEVEL_SORT_ORDER removed

interface RiskAnalysisPanelProps {
  risks: AnalyzedRisk[]; // Changed prop name to 'risks' to match what App.tsx passes as 'sortedAnalyzedRisks'
  activeRiskId: string | null;
  setActiveRiskId: (id: string | null) => void;
}

export const RiskAnalysisPanel: React.FC<RiskAnalysisPanelProps> = ({ risks: sortedRisks, activeRiskId, setActiveRiskId }) => {
  const [expandedRiskId, setExpandedRiskId] = useState<string | null>(null);

  // sortedRisks is now received as a prop, already sorted.
  // const sortedRisks = useMemo(() => {
  //   return [...risks].sort((a, b) => {
  //     return RISK_LEVEL_SORT_ORDER[a.calculatedRiskLevel] - RISK_LEVEL_SORT_ORDER[b.calculatedRiskLevel] || a.label.localeCompare(b.label, 'th');
  //   });
  // }, [risks]);

  const toggleExpandRisk = (riskId: string) => {
    const newExpandedId = expandedRiskId === riskId ? null : riskId;
    setExpandedRiskId(newExpandedId);
    setActiveRiskId(newExpandedId); 
    if (newExpandedId) {
      setTimeout(() => { 
        const element = document.getElementById('detailed-assessment-section');
        element?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  };

  if (sortedRisks.length === 0) {
    return (
      <div className="bg-gray-800 p-6 rounded-xl shadow-2xl">
        <h2 className="text-2xl font-semibold mb-4 text-sky-400">{THAI_LABELS.RISK_SUMMARY}</h2>
        <p className="text-gray-400">{THAI_LABELS.RISK_SUMMARY_EMPTY}</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="bg-gray-800 p-6 rounded-xl shadow-2xl">
        <h2 className="text-2xl font-semibold mb-6 text-sky-400">{THAI_LABELS.RISK_SUMMARY}</h2>
        <div className="space-y-3">
          {sortedRisks.map((risk, index) => (
            <div
              key={risk.id}
              onClick={() => toggleExpandRisk(risk.id)}
              onMouseEnter={() => setActiveRiskId(risk.id)} 
              // onMouseLeave={() => setActiveRiskId(expandedRiskId)} // Kept commented as per original
              className={`p-4 rounded-lg shadow-md cursor-pointer transition-all duration-200 ease-in-out border-2
                ${risk.id === activeRiskId || risk.id === expandedRiskId ? 'border-sky-500 ring-2 ring-sky-500/50' : 'border-transparent hover:border-sky-600/70'}
                ${RISK_LEVEL_COLORS[risk.calculatedRiskLevel]}
                ${risk.id === expandedRiskId ? 'scale-105' : 'hover:scale-[1.02]'}`}
              role="button"
              aria-expanded={risk.id === expandedRiskId}
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') toggleExpandRisk(risk.id);}}
            >
              <div className="flex justify-between items-center">
                <span className={`font-medium text-lg ${risk.calculatedRiskLevel === RiskLevel.MEDIUM || risk.calculatedRiskLevel === RiskLevel.LOW ? 'text-gray-800' : 'text-white' }`}>{index + 1}. {risk.label}</span>
                <span className={`px-3 py-1 text-xs font-semibold rounded-full shadow-sm
                  ${risk.calculatedRiskLevel === RiskLevel.HIGH ? 'bg-red-700 text-white' :
                    risk.calculatedRiskLevel === RiskLevel.MEDIUM ? 'bg-amber-600 text-white' : 
                    risk.calculatedRiskLevel === RiskLevel.LOW ? 'bg-emerald-700 text-white' :
                    'bg-gray-600 text-white'}`}>
                  {risk.calculatedRiskLevel}
                </span>
              </div>
              {risk.id === expandedRiskId && risk.detailedAssessment && (
                <div className={`mt-4 pt-4 border-t ${risk.calculatedRiskLevel === RiskLevel.MEDIUM || risk.calculatedRiskLevel === RiskLevel.LOW ? 'border-gray-400/50' : 'border-gray-600/50'}`}>
                   <p className={`text-sm italic ${risk.calculatedRiskLevel === RiskLevel.MEDIUM || risk.calculatedRiskLevel === RiskLevel.LOW ? 'text-gray-700' : 'text-gray-300' }`}>{risk.detailedAssessment.riskLevelDescription}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {expandedRiskId && sortedRisks.find(r => r.id === expandedRiskId)?.detailedAssessment && (
        <div id="detailed-assessment-section" className="bg-gray-800 p-6 rounded-xl shadow-2xl">
           <h2 className="text-2xl font-semibold mb-6 text-sky-400">{THAI_LABELS.DETAILED_REPORT}</h2>
           <RiskAssessmentTable risk={sortedRisks.find(r => r.id === expandedRiskId)!} />
        </div>
      )}
       {expandedRiskId && !sortedRisks.find(r => r.id === expandedRiskId)?.detailedAssessment && (
         <div id="detailed-assessment-section" className="bg-gray-800 p-6 rounded-xl shadow-2xl">
           <h2 className="text-2xl font-semibold mb-6 text-sky-400">{THAI_LABELS.DETAILED_REPORT}</h2>
           <p className="text-gray-400">{THAI_LABELS.NO_DETAILS_AVAILABLE}</p>
        </div>
       )}
    </div>
  );
};
