
import React, { useState } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import type { AnalyzedRisk } from '../types';
import { RiskLevel } from '../types';
import { THAI_LABELS } from '../constants';

interface PdfExportButtonProps {
  risks: AnalyzedRisk[];
  imageUrl: string | null;
  imageName: string;
  assessmentTitle?: string;
}

const escapeHtml = (unsafe: string): string => {
    if (typeof unsafe !== 'string') return String(unsafe); // Ensure it's a string
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
};

// Helper to render HTML content via html2canvas and add to PDF
const addHtmlContentToPdf = async (
    pdf: jsPDF, 
    htmlContent: string, 
    currentY: number, 
    pageWidth: number, 
    pageHeight: number, 
    margin: number
): Promise<number> => {
    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px'; // Off-screen
    const contentWidthPx = ((pageWidth - 2 * margin) / 25.4) * 96; // A4 content width in pixels
    container.style.width = `${contentWidthPx}px`;
    container.style.padding = `1px`; // Minimal padding, styling should be in htmlContent
    container.style.backgroundColor = 'white';
    container.style.color = 'black';
    container.style.fontFamily = '"Tahoma", "Arial", "Helvetica", sans-serif'; // Common fonts
    container.innerHTML = htmlContent;
    document.body.appendChild(container);

    const canvas = await html2canvas(container, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: 'white',
    });
    const imgData = canvas.toDataURL('image/png');
    document.body.removeChild(container);

    const imgProps = pdf.getImageProperties(imgData);
    let pdfImgHeight = (imgProps.height * (pageWidth - 2 * margin)) / imgProps.width;
    
    if (currentY + pdfImgHeight > pageHeight - margin) {
        pdf.addPage();
        currentY = margin;
    }
    pdf.addImage(imgData, 'PNG', margin, currentY, pageWidth - 2 * margin, pdfImgHeight);
    return currentY + pdfImgHeight + 1; // Small spacing
};


const PdfExportButton: React.FC<PdfExportButtonProps> = ({ risks, imageUrl, imageName, assessmentTitle }) => {
  const [isExporting, setIsExporting] = useState(false);

  const exportToPdf = async () => {
    setIsExporting(true);
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageHeight = pdf.internal.pageSize.getHeight();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const margin = 10;
    let yPos = margin;

    // --- Render Header using html2canvas ---
    const headerHtml = `
      <div style="text-align: center; margin-bottom: 8px; font-size: 16pt; color: #333;">
        <strong>${escapeHtml(assessmentTitle || `${THAI_LABELS.ASSESSMENT_FOR} ${imageName}`)}</strong>
      </div>
      <div style="font-size: 10pt; color: #555; margin-bottom: 10px;">
        ${THAI_LABELS.DATE_TIME_ASSESSED}: ${escapeHtml(new Date().toLocaleString('th-TH', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }))}
      </div>
    `;
    yPos = await addHtmlContentToPdf(pdf, headerHtml, yPos, pageWidth, pageHeight, margin);
    yPos += 5; // Additional space after header block

    // Image Preview Section
    const imageDisplayCanvasElement = document.querySelector('#image-preview-for-pdf canvas');
    if (imageUrl && imageDisplayCanvasElement instanceof HTMLCanvasElement) {
        const parentElementForCapture = imageDisplayCanvasElement.parentElement || imageDisplayCanvasElement;
        const originalBg = parentElementForCapture.style.backgroundColor;
        if (!parentElementForCapture.style.backgroundColor) {
             parentElementForCapture.style.backgroundColor = '#1f2937'; 
        }

        const capturedCanvas = await html2canvas(parentElementForCapture, {
            useCORS: true, scale: 2, logging: false, backgroundColor: parentElementForCapture.style.backgroundColor || '#ffffff',
        });
        if (!originalBg) parentElementForCapture.style.backgroundColor = '';

        const imgData = capturedCanvas.toDataURL('image/png');
        const imgProps = pdf.getImageProperties(imgData);
        let pdfImgWidth = pageWidth - 2 * margin;
        let pdfImgHeight = (imgProps.height * pdfImgWidth) / imgProps.width;
        const maxImgHeight = pageHeight * 0.35; 

        if (pdfImgHeight > maxImgHeight) {
            pdfImgHeight = maxImgHeight;
            pdfImgWidth = (imgProps.width * pdfImgHeight) / imgProps.height;
        }
        if (pdfImgWidth > pageWidth - 2 * margin) {
            pdfImgWidth = pageWidth - 2 * margin;
            pdfImgHeight = (imgProps.height * pdfImgWidth) / imgProps.width;
        }
        
        if (yPos + pdfImgHeight + margin > pageHeight) {
            pdf.addPage();
            yPos = margin;
        }
        pdf.addImage(imgData, 'PNG', margin + ((pageWidth - 2 * margin) - pdfImgWidth) / 2 , yPos, pdfImgWidth, pdfImgHeight);
        yPos += pdfImgHeight + 8; // Spacing after image

    } else if (imageUrl) { 
        // Fallback for direct image add - might not render Thai text embedded in images well, but main text handled by html2canvas now.
        try {
            const img = new Image();
            img.crossOrigin = "anonymous";
            img.src = imageUrl;
            await new Promise((resolve, reject) => { img.onload = resolve; img.onerror = reject; });

            const imgProps = pdf.getImageProperties(imageUrl);
            let pdfImgWidth = pageWidth - 2 * margin;
            let pdfImgHeight = (imgProps.height * pdfImgWidth) / imgProps.width;
            const maxImgHeight = pageHeight * 0.35;
            if (pdfImgHeight > maxImgHeight) { /* ... (adjust dimensions as above) ... */ }
            if (yPos + pdfImgHeight + margin > pageHeight) { pdf.addPage(); yPos = margin; }
            pdf.addImage(imageUrl, imgProps.format || 'JPEG', margin, yPos, pdfImgWidth, pdfImgHeight);
            yPos += pdfImgHeight + 8;
        } catch (e) {
             console.error("Error adding fallback image to PDF:", e);
             const errorHtml = `<div style="color: red; font-size: 10pt;">Error displaying image in PDF.</div>`;
             yPos = await addHtmlContentToPdf(pdf, errorHtml, yPos, pageWidth, pageHeight, margin);
        }
    }
    
    // Risk details loop
    for (const risk of risks) {
        if (yPos > pageHeight - margin - 30) { // Estimate space for next block header
            pdf.addPage();
            yPos = margin;
        }

        let riskHtml = `<div style="margin-bottom: 7px; padding: 1px; border: 0.5px solid #d0d0d0; font-size: 9.5pt; line-height: 1.4;">`;
        
        const riskLevelColor = risk.calculatedRiskLevel === RiskLevel.HIGH ? 'rgb(200, 38, 38)' :
                               risk.calculatedRiskLevel === RiskLevel.MEDIUM ? 'rgb(230, 148, 11)' :
                               risk.calculatedRiskLevel === RiskLevel.LOW ? 'rgb(16, 165, 109)' : 'rgb(97, 104, 118)';
        
        riskHtml += `<div style="background-color: ${riskLevelColor}; color: white; padding: 5px; margin-bottom: 5px; font-size: 10.5pt;">`;
        riskHtml += `<strong>${THAI_LABELS.RISK} ${risks.indexOf(risk) + 1}: ${escapeHtml(risk.label)} (${escapeHtml(risk.calculatedRiskLevel)})</strong>`;
        riskHtml += `</div>`;

        riskHtml += `<div style="padding: 0 5px;">`;
        if (risk.detailedAssessment) {
            const da = risk.detailedAssessment;
            riskHtml += `<p style="margin: 2px 0;"><strong>${THAI_LABELS.SEVERITY}:</strong> ${escapeHtml(String(da.severity))}</p>`;
            riskHtml += `<p style="margin: 2px 0;"><strong>${THAI_LABELS.LIKELIHOOD}:</strong> ${escapeHtml(String(da.likelihood))}</p>`;
            riskHtml += `<p style="margin: 2px 0;"><strong>${THAI_LABELS.RISK_LEVEL_DESCRIPTION}:</strong> ${escapeHtml(da.riskLevelDescription)}</p>`;

            const renderList = (title: string, items: string[]) => {
                if (!items || items.length === 0) return '<p style="margin: 2px 0;"><strong>' + escapeHtml(title) + ':</strong> - </p>';
                let html = `<p style="margin: 2px 0; margin-bottom: 0px;"><strong>${escapeHtml(title)}:</strong></p><ul style="margin-top: 0px; margin-left: 18px; padding-left: 0; font-size: 9pt; list-style-type: disc;">`;
                items.forEach(item => { html += `<li style="margin-bottom: 1px;">${escapeHtml(item)}</li>`; });
                html += `</ul>`;
                return html;
            };

            riskHtml += renderList(THAI_LABELS.CORRECTIVE_MEASURES, da.correctivePreventiveMeasures);
            riskHtml += renderList(THAI_LABELS.INTERNATIONAL_STANDARDS, da.internationalStandards);
            riskHtml += renderList(THAI_LABELS.THAI_LAWS, da.thaiLaws);
            if (da.kubotaStandards && da.kubotaStandards.length > 0) {
                riskHtml += renderList(THAI_LABELS.KUBOTA_STANDARDS, da.kubotaStandards);
            }
        } else {
            riskHtml += `<p>${THAI_LABELS.NO_DETAILS_AVAILABLE}</p>`;
        }
        riskHtml += `</div></div>`; 

        yPos = await addHtmlContentToPdf(pdf, riskHtml, yPos, pageWidth, pageHeight, margin);
        yPos += 2; // Extra spacing between risk items
    }

    pdf.save(`${imageName.split('.')[0]}_RiskAssessment_${new Date().toISOString().split('T')[0]}.pdf`);
    setIsExporting(false);
  };
  
  return (
    <button
      onClick={exportToPdf}
      disabled={isExporting || risks.length === 0 || !imageUrl}
      className="w-full bg-sky-600 hover:bg-sky-500 text-white font-semibold py-3 px-4 rounded-lg shadow-md transition duration-150 ease-in-out flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {isExporting ? (
        <SpinnerIcon className="w-5 h-5 mr-2 animate-spin" />
      ) : (
        <DocumentArrowDownIcon className="w-5 h-5 mr-2" />
      )}
      {isExporting ? THAI_LABELS.EXPORTING_PDF : THAI_LABELS.EXPORT_PDF}
    </button>
  );
};

const DocumentArrowDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);

const SpinnerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" {...props}>
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

export default PdfExportButton;
