
import React from 'react';
import type { AnalyzedRisk } from '../types';
import { RiskLevel } from '../types';
import { THAI_LABELS, HIERARCHY_OF_CONTROLS_ORDER } from '../constants'; // RISK_LEVEL_COLORS removed as it's not directly used for table rows here.

interface RiskAssessmentTableProps {
  risk: AnalyzedRisk;
}

const getRiskLevelRowClass = (level: RiskLevel): string => {
  switch (level) {
    case RiskLevel.HIGH:
      return 'bg-red-700 hover:bg-red-600';
    case RiskLevel.MEDIUM:
      return 'bg-amber-600 hover:bg-amber-500';
    case RiskLevel.LOW:
      return 'bg-emerald-700 hover:bg-emerald-600';
    default:
      return 'bg-gray-600 hover:bg-gray-500';
  }
};

const renderMeasures = (measures: string[]) => {
  const sortedMeasures = [...measures].sort((a, b) => {
    const indexA = HIERARCHY_OF_CONTROLS_ORDER.findIndex(keyword => keyword.test(a));
    const indexB = HIERARCHY_OF_CONTROLS_ORDER.findIndex(keyword => keyword.test(b));
    
    const valA = indexA === -1 ? HIERARCHY_OF_CONTROLS_ORDER.length : indexA;
    const valB = indexB === -1 ? HIERARCHY_OF_CONTROLS_ORDER.length : indexB;
    
    return valA - valB;
  });

  return (
    <ul className="list-disc list-inside space-y-1">
      {sortedMeasures.map((measure, index) => (
        <li key={index}>{measure}</li>
      ))}
    </ul>
  );
};

export const RiskAssessmentTable: React.FC<RiskAssessmentTableProps> = ({ risk }) => {
  if (!risk.detailedAssessment) {
    return <p className="text-gray-400">{THAI_LABELS.RISK} "{risk.label}" {THAI_LABELS.NO_DETAILS_AVAILABLE}</p>;
  }

  const { detailedAssessment, calculatedRiskLevel } = risk;

  return (
    <div className="overflow-x-auto bg-gray-800 text-gray-200 rounded-lg shadow-lg">
      <table className="min-w-full divide-y divide-gray-700">
        <thead className="bg-gray-750">
          <tr>
            <th colSpan={2} className="px-6 py-4 text-left text-xl font-semibold text-sky-400">
              {THAI_LABELS.RISK}: {risk.label}
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-700">
          <tr className={`${getRiskLevelRowClass(calculatedRiskLevel)} transition-colors duration-150`}>
            <td className="px-6 py-4 font-medium text-gray-50 whitespace-nowrap">{THAI_LABELS.HAZARD_DESCRIPTION}</td>
            <td className="px-6 py-4 text-gray-100">{risk.label}</td>
          </tr>
          <tr className={`${getRiskLevelRowClass(calculatedRiskLevel)} transition-colors duration-150`}>
            <td className="px-6 py-4 font-medium text-gray-50 whitespace-nowrap">{THAI_LABELS.SEVERITY} (1-5)</td>
            <td className="px-6 py-4 text-gray-100">{detailedAssessment.severity}</td>
          </tr>
          <tr className={`${getRiskLevelRowClass(calculatedRiskLevel)} transition-colors duration-150`}>
            <td className="px-6 py-4 font-medium text-gray-50 whitespace-nowrap">{THAI_LABELS.LIKELIHOOD} (1-5)</td>
            <td className="px-6 py-4 text-gray-100">{detailedAssessment.likelihood}</td>
          </tr>
          <tr className={`${getRiskLevelRowClass(calculatedRiskLevel)} transition-colors duration-150`}>
            <td className="px-6 py-4 font-medium text-gray-50 whitespace-nowrap">{THAI_LABELS.RISK_LEVEL}</td>
            <td className={`px-6 py-4 font-bold text-lg ${
                calculatedRiskLevel === RiskLevel.HIGH ? 'text-red-300' :
                calculatedRiskLevel === RiskLevel.MEDIUM ? 'text-amber-300' :
                calculatedRiskLevel === RiskLevel.LOW ? 'text-emerald-300' : 'text-gray-300'
            }`}>
              {calculatedRiskLevel}
            </td>
          </tr>
           <tr className="bg-gray-700 hover:bg-gray-600 transition-colors duration-150">
            <td className="px-6 py-4 font-medium text-gray-50 whitespace-nowrap">{THAI_LABELS.RISK_LEVEL_DESCRIPTION}</td>
            <td className="px-6 py-4 text-gray-100">{detailedAssessment.riskLevelDescription}</td>
          </tr>
          <tr className="bg-gray-700 hover:bg-gray-600 transition-colors duration-150">
            <td className="px-6 py-4 font-medium text-gray-50 align-top whitespace-nowrap">{THAI_LABELS.CORRECTIVE_MEASURES}</td>
            <td className="px-6 py-4 text-gray-100">
              {detailedAssessment.correctivePreventiveMeasures.length > 0 ? 
                renderMeasures(detailedAssessment.correctivePreventiveMeasures) : '-'}
            </td>
          </tr>
          <tr className="bg-gray-700 hover:bg-gray-600 transition-colors duration-150">
            <td className="px-6 py-4 font-medium text-gray-50 align-top whitespace-nowrap">{THAI_LABELS.INTERNATIONAL_STANDARDS}</td>
            <td className="px-6 py-4 text-gray-100">
              {detailedAssessment.internationalStandards.length > 0 ? (
                <ul className="list-disc list-inside space-y-1">
                  {detailedAssessment.internationalStandards.map((std, index) => <li key={index}>{std}</li>)}
                </ul>
              ) : '-'}
            </td>
          </tr>
          <tr className="bg-gray-700 hover:bg-gray-600 transition-colors duration-150">
            <td className="px-6 py-4 font-medium text-gray-50 align-top whitespace-nowrap">{THAI_LABELS.THAI_LAWS}</td>
            <td className="px-6 py-4 text-gray-100">
              {detailedAssessment.thaiLaws.length > 0 ? (
                <ul className="list-disc list-inside space-y-1">
                  {detailedAssessment.thaiLaws.map((law, index) => <li key={index}>{law}</li>)}
                </ul>
              ) : '-'}
            </td>
          </tr>
          {detailedAssessment.kubotaStandards && (
            <tr className="bg-gray-700 hover:bg-gray-600 transition-colors duration-150">
              <td className="px-6 py-4 font-medium text-gray-50 align-top whitespace-nowrap">{THAI_LABELS.KUBOTA_STANDARDS}</td>
              <td className="px-6 py-4 text-gray-100">
                {detailedAssessment.kubotaStandards.length > 0 ? (
                  <ul className="list-disc list-inside space-y-1">
                    {detailedAssessment.kubotaStandards.map((ks, index) => <li key={index}>{ks}</li>)}
                  </ul>
                ) : '-'}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

// Removed THAI_LABELS augmentation code (declare module and if block)
// as labels are now centrally defined in constants.ts.
