
import React, { useState } from 'react';
import type { AssessmentRecord } from '../types';
import { THAI_LABELS } from '../constants';
import PdfExportButton from './PdfExportButton'; 

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: AssessmentRecord[];
  onLoadItem: (record: AssessmentRecord) => void;
  onDeleteItem: (id: string) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({ isOpen, onClose, history, onLoadItem, onDeleteItem }) => {
  const [itemToDelete, setItemToDelete] = useState<AssessmentRecord | null>(null);

  if (!isOpen) return null;

  const confirmDelete = (record: AssessmentRecord) => {
    setItemToDelete(record);
  };

  const handleDelete = () => {
    if (itemToDelete) {
      onDeleteItem(itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const sortedHistory = [...history].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-75 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 text-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-6 border-b border-gray-700">
          <h2 className="text-2xl font-semibold text-sky-400">{THAI_LABELS.ASSESSMENT_HISTORY}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-4 overflow-y-auto flex-grow">
          {sortedHistory.length === 0 ? (
            <p className="text-gray-400 text-center py-8">{THAI_LABELS.NO_HISTORY}</p>
          ) : (
            sortedHistory.map(record => (
              <div key={record.id} className="bg-gray-750 p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-3">
                  <h3 className="text-lg font-medium text-sky-300 flex-grow mr-2 break-all pr-2">{record.assessmentTitle || record.imageName}</h3>
                  <p className="text-xs text-gray-400 mt-1 sm:mt-0 flex-shrink-0">
                    {new Date(record.timestamp).toLocaleString('th-TH', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 mt-3">
                    <div className="flex-grow flex gap-2">
                         <button
                            onClick={() => onLoadItem(record)}
                            className="bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold py-2 px-3 rounded-md transition duration-150 flex items-center w-full sm:w-auto justify-center"
                        >
                            <LoadIcon className="w-4 h-4 mr-1.5" /> {THAI_LABELS.LOAD_ASSESSMENT}
                        </button>
                        {record.analyzedRisks && record.analyzedRisks.length > 0 && (
                            <div className="w-full sm:w-auto">
                                <PdfExportButton 
                                    risks={record.analyzedRisks} 
                                    imageUrl={record.imageUrl} 
                                    imageName={record.imageName}
                                    assessmentTitle={record.assessmentTitle}
                                />
                            </div>
                        )}
                    </div>
                  <button
                    onClick={() => confirmDelete(record)}
                    className="bg-red-600 hover:bg-red-500 text-white text-sm font-semibold py-2 px-3 rounded-md transition duration-150 flex items-center  w-full sm:w-auto justify-center"
                  >
                    <DeleteIcon className="w-4 h-4 mr-1.5" /> {THAI_LABELS.DELETE_ASSESSMENT}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="p-4 sm:p-6 border-t border-gray-700 text-right">
            <button 
                onClick={onClose}
                className="bg-gray-600 hover:bg-gray-500 text-white font-semibold py-2.5 px-5 rounded-lg shadow-md transition duration-150"
            >
                {THAI_LABELS.CLOSE}
            </button>
        </div>
      </div>

      {itemToDelete && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl max-w-sm w-full border border-gray-700">
            <h3 className="text-xl font-semibold mb-4 text-red-400">{THAI_LABELS.CONFIRM_DELETE_TITLE}</h3>
            <p className="text-gray-300 mb-6">{THAI_LABELS.CONFIRM_DELETE_MESSAGE(itemToDelete.assessmentTitle || itemToDelete.imageName)}</p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 rounded-md text-gray-300 bg-gray-600 hover:bg-gray-500 transition-colors"
              >
                {THAI_LABELS.CANCEL}
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 rounded-md text-white bg-red-600 hover:bg-red-500 transition-colors"
              >
                {THAI_LABELS.DELETE}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const CloseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);
const LoadIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
  </svg>
);
const DeleteIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c-.34-.059-.68-.114-1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
  </svg>
);
