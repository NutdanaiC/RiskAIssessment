
import React, { useRef, useEffect, useState, useCallback } from 'react';
import type { AnalyzedRisk } from '../types';
import { RiskLevel } from '../types';
import { THAI_LABELS } from '../constants';

interface ImageDisplayProps {
  imageUrl: string | null;
  sortedRisks: AnalyzedRisk[];
  onRiskHover: (riskId: string | null) => void;
  onRiskClick: (riskId: string | null) => void;
  activeRiskId: string | null;
  revealOnHover: boolean;
}

interface ImageDimensions {
  width: number;
  height: number;
  naturalWidth: number;
  naturalHeight: number;
}

export const ImageDisplay: React.FC<ImageDisplayProps> = ({ imageUrl, sortedRisks, onRiskHover, onRiskClick, activeRiskId, revealOnHover }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [imageDimensions, setImageDimensions] = useState<ImageDimensions | null>(null);
  const [hoveredRiskLabel, setHoveredRiskLabel] = useState<string | null>(null);
  const [mousePosition, setMousePosition] = useState<{ x: number, y: number } | null>(null);

  const getRiskColor = (level: RiskLevel, alpha: number = 0.4): string => {
    switch (level) {
      case RiskLevel.HIGH: return `rgba(239, 68, 68, ${alpha})`; 
      case RiskLevel.MEDIUM: return `rgba(245, 158, 11, ${alpha})`; 
      case RiskLevel.LOW: return `rgba(16, 185, 129, ${alpha})`; 
      default: return `rgba(107, 114, 128, ${alpha})`; 
    }
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas || !imageDimensions) return;

    const { width, height, naturalWidth, naturalHeight } = imageDimensions;
    canvas.width = width;
    canvas.height = height;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = imageUrl!;
    img.onload = () => {
      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      sortedRisks.forEach((risk, index) => {
        const isThisRiskActive = risk.id === activeRiskId;
        // Determine if the mask should be fully revealed or just an outline
        const showFullMask = !revealOnHover || (revealOnHover && isThisRiskActive);

        if (risk.maskPoints && risk.maskPoints.length > 2) {
          ctx.beginPath();
          const firstPoint = risk.maskPoints[0];
          ctx.moveTo(firstPoint[0] * (width / naturalWidth), firstPoint[1] * (height / naturalHeight));
          for (let i = 1; i < risk.maskPoints.length; i++) {
            const point = risk.maskPoints[i];
            ctx.lineTo(point[0] * (width / naturalWidth), point[1] * (height / naturalHeight));
          }
          ctx.closePath();

          if (showFullMask) {
            // Full display: fill, prominent stroke, number
            ctx.fillStyle = getRiskColor(risk.calculatedRiskLevel, isThisRiskActive ? 0.6 : 0.4);
            ctx.fill();
            ctx.strokeStyle = getRiskColor(risk.calculatedRiskLevel, 1);
            ctx.lineWidth = isThisRiskActive ? 3 : 1.5;
            ctx.stroke();

            // Draw number on the mask (only for fully revealed masks)
            const displayIndexString = (index + 1).toString();
            const scaledBoxX = risk.boundingBox[0] * (width / naturalWidth);
            const scaledBoxY = risk.boundingBox[1] * (height / naturalHeight);
            const scaledBoxW = risk.boundingBox[2] * (width / naturalWidth);
            const scaledBoxH = risk.boundingBox[3] * (height / naturalHeight);

            const centerX = scaledBoxX + scaledBoxW / 2;
            const centerY = scaledBoxY + scaledBoxH / 2;

            const numberCircleRadius = 10; 
            const numberFontSize = 12; 

            ctx.beginPath();
            ctx.arc(centerX, centerY, numberCircleRadius, 0, 2 * Math.PI, false);
            ctx.fillStyle = 'rgba(30, 41, 59, 0.85)'; 
            ctx.fill();
            ctx.strokeStyle = 'rgba(203, 213, 225, 0.9)';
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.font = `bold ${numberFontSize}px Arial, sans-serif`;
            ctx.fillStyle = 'white';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(displayIndexString, centerX, centerY);

          } else if (revealOnHover) { 
            // Outline only display (when revealOnHover is true and this risk is not active)
            ctx.strokeStyle = getRiskColor(risk.calculatedRiskLevel, 0.8); // Make outline slightly more prominent
            ctx.lineWidth = 1.5;
            ctx.stroke();
          }
        }
      });
    };
     img.onerror = () => {
        console.error("Failed to load image for canvas drawing:", imageUrl);
         if (ctx) { 
            ctx.clearRect(0, 0, width, height);
            ctx.fillStyle = "black";
            ctx.fillRect(0,0, width, height);
            ctx.font = "16px Arial";
            ctx.fillStyle = "white";
            ctx.textAlign = "center";
            ctx.fillText("Error loading image", width/2, height/2);
        }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [imageUrl, sortedRisks, imageDimensions, activeRiskId, revealOnHover]);


  useEffect(() => {
    const img = new Image();
    if (imageUrl) {
      img.crossOrigin = "anonymous";
      img.src = imageUrl;
      img.onload = () => {
        const container = containerRef.current;
        if (container) {
          const aspectRatio = img.naturalWidth / img.naturalHeight;
          let newWidth = container.offsetWidth;
          let newHeight = newWidth / aspectRatio;

          if (newHeight > window.innerHeight * 0.7) { 
            newHeight = window.innerHeight * 0.7;
            newWidth = newHeight * aspectRatio;
          }
           if (newWidth > container.offsetWidth) { 
            newWidth = container.offsetWidth;
            newHeight = newWidth / aspectRatio;
          }

          setImageDimensions({
            width: newWidth,
            height: newHeight,
            naturalWidth: img.naturalWidth,
            naturalHeight: img.naturalHeight,
          });
        }
      };
       img.onerror = () => {
        console.error("Failed to load image for dimension calculation:", imageUrl);
        setImageDimensions(null); 
      };
    } else {
        setImageDimensions(null); 
    }

    const handleResize = () => { 
        if (imageUrl) {
            const currentImg = new Image();
            currentImg.crossOrigin = "anonymous";
            currentImg.src = imageUrl;
            currentImg.onload = () => { 
                 const container = containerRef.current;
                if (container) {
                    const aspectRatio = currentImg.naturalWidth / currentImg.naturalHeight;
                    let newWidth = container.offsetWidth;
                    let newHeight = newWidth / aspectRatio;

                    if (newHeight > window.innerHeight * 0.7) {
                        newHeight = window.innerHeight * 0.7;
                        newWidth = newHeight * aspectRatio;
                    }
                    if (newWidth > container.offsetWidth) {
                      newWidth = container.offsetWidth;
                      newHeight = newWidth / aspectRatio;
                    }
                    setImageDimensions({
                        width: newWidth,
                        height: newHeight,
                        naturalWidth: currentImg.naturalWidth,
                        naturalHeight: currentImg.naturalHeight,
                    });
                }
            }
            currentImg.onerror = () => {
                 console.error("Failed to load image for resize handling:", imageUrl);
            }
        }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);

  }, [imageUrl]);


  useEffect(() => {
    if (imageDimensions) { 
        draw();
    }
  }, [draw, imageDimensions]); 

  const handleCanvasInteraction = (event: React.MouseEvent<HTMLCanvasElement>, type: 'hover' | 'click') => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas || !imageDimensions) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    setMousePosition({ x: event.clientX, y: event.clientY }); 

    let foundRiskId: string | null = null;
    
    for (let i = sortedRisks.length - 1; i >= 0; i--) {
      const risk = sortedRisks[i];
      if (risk.maskPoints && risk.maskPoints.length > 2) {
        // Perform hit test for the mask polygon
        ctx.beginPath();
        const firstPoint = risk.maskPoints[0];
        ctx.moveTo(firstPoint[0] * (imageDimensions.width / imageDimensions.naturalWidth), firstPoint[1] * (imageDimensions.height / imageDimensions.naturalHeight));
        for (let j = 1; j < risk.maskPoints.length; j++) {
          const point = risk.maskPoints[j];
          ctx.lineTo(point[0] * (imageDimensions.width / imageDimensions.naturalWidth), point[1] * (imageDimensions.height / imageDimensions.naturalHeight));
        }
        ctx.closePath();
        if (ctx.isPointInPath(x, y)) {
          foundRiskId = risk.id;
          break; 
        }
      }
    }

    if (type === 'hover') {
      onRiskHover(foundRiskId);
      setHoveredRiskLabel(foundRiskId ? sortedRisks.find(r => r.id === foundRiskId)?.label || null : null);
    } else if (type === 'click') {
      onRiskClick(foundRiskId);
    }
  };
  
  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => handleCanvasInteraction(event, 'hover');
  const handleClick = (event: React.MouseEvent<HTMLCanvasElement>) => handleCanvasInteraction(event, 'click');
  const handleMouseLeave = () => {
    onRiskHover(null);
    setHoveredRiskLabel(null);
    setMousePosition(null);
  };


  if (!imageUrl) return null;

  return (
    <div ref={containerRef} className="relative w-full flex justify-center items-center">
      <canvas
        ref={canvasRef}
        onMouseMove={handleMouseMove}
        onClick={handleClick}
        onMouseLeave={handleMouseLeave}
        className="rounded-lg shadow-lg border border-gray-700 bg-gray-900"
        style={{ maxWidth: '100%', maxHeight: '70vh', display: imageDimensions ? 'block' : 'none', cursor: 'crosshair' }}
        aria-label={THAI_LABELS.IMAGE_PREVIEW}
      />
      {hoveredRiskLabel && mousePosition && containerRef.current && (
        <div
          className="absolute p-2 bg-gray-900 text-white text-sm rounded-md shadow-xl pointer-events-none transform -translate-y-full " 
          style={{ 
            left: mousePosition.x - containerRef.current.getBoundingClientRect().left + 10, 
            top: mousePosition.y - containerRef.current.getBoundingClientRect().top - 10 
          }}
          role="tooltip"
        >
          {THAI_LABELS.MASK_LABEL_PREFIX} {hoveredRiskLabel}
        </div>
      )}
      {!imageDimensions && imageUrl && ( 
        <div className="w-full h-64 bg-gray-700 rounded-lg flex items-center justify-center text-gray-400">
            กำลังโหลดภาพ...
        </div>
      )}
    </div>
  );
};
