
import { RiskLevel } from '../types';
// SeverityLikelihood type not directly used in this file but good for context
// import type { SeverityLikelihood } from '../types'; 

export const calculateRiskLevel = (severity: number, likelihood: number): RiskLevel => {
  const s = Math.max(1, Math.min(5, Math.round(Number(severity) || 1))); // Ensure valid number, default to 1
  const l = Math.max(1, Math.min(5, Math.round(Number(likelihood) || 1))); // Ensure valid number, default to 1

  const riskScore = s * l;

  if (riskScore >= 15) { // 15-25: High
    return RiskLevel.HIGH;
  } else if (riskScore >= 6) { // 6-12: Medium (Note: A score of 5 (e.g. 5x1) is Low)
    return RiskLevel.MEDIUM;
  } else { // 1-5: Low
    return RiskLevel.LOW;
  }
};

export const getRiskMatrix = (): Array<Array<RiskLevel>> => {
  const matrix: Array<Array<RiskLevel>> = [];
  // Likelihood (rows: 1 to 5)
  for (let l_idx = 0; l_idx < 5; l_idx++) { 
    const likelihoodValue = l_idx + 1;
    const row: RiskLevel[] = [];
    // Severity (columns: 1 to 5)
    for (let s_idx = 0; s_idx < 5; s_idx++) { 
      const severityValue = s_idx + 1;
      row.push(calculateRiskLevel(severityValue, likelihoodValue));
    }
    matrix.push(row);
  }
  // matrix[likelihood-1][severity-1] gives RiskLevel
  // Example: matrix[0][0] is L=1, S=1
  // matrix[4][4] is L=5, S=5
  return matrix;
};
