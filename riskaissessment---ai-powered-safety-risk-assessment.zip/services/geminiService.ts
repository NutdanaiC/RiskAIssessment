
import { GoogleGenAI } from "@google/genai";
import type { GenerateContentResponse } from "@google/genai";
import { GEMINI_API_KEY, GEMINI_IMAGE_ANALYSIS_PROMPT_TEMPLATE, GEMINI_DETAILED_ASSESSMENT_PROMPT_TEMPLATE } from '../constants';
import type { DetectedRiskCore, DetailedAssessment, RawGeminiDetection, RawGeminiDetectionResponse, RawGeminiDetailedAssessment, RawGeminiDetailedResponse, TextModelId } from '../types';

// Helper function to get the AI client, ensuring API key is valid
function getAiClient(): GoogleGenAI {
  if (!GEMINI_API_KEY) {
    // This specific error message will be caught and displayed by App.tsx
    throw new Error("API_KEY environment variable is not set or is invalid. Please ensure it is configured correctly in the build environment.");
  }
  return new GoogleGenAI({ apiKey: GEMINI_API_KEY });
}

const parseGeminiJsonResponse = <T,>(text: string, context: string): T => {
  // text is the raw response from Gemini
  let jsonStrToParse = text.trim();

  // Initial BOM removal
  if (jsonStrToParse.startsWith('\uFEFF')) {
    jsonStrToParse = jsonStrToParse.substring(1);
  }

  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; 
  const match = jsonStrToParse.match(fenceRegex);
  if (match && match[2]) {
    jsonStrToParse = match[2].trim();
    if (jsonStrToParse.startsWith('\uFEFF')) {
        jsonStrToParse = jsonStrToParse.substring(1);
    }
  }

  // Aggressive cleaning for invisible/control characters
  jsonStrToParse = jsonStrToParse.replace(/[\u200B-\u200D\uFEFF]/g, '');
  jsonStrToParse = jsonStrToParse.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');

  // Attempt to fix missing colons after property names.
  const fixMissingColonRegex = /("\s*(?:[^"\\]|\\.)+\s*")\s+(?=("(?:[^"\\]|\\.)+"|[\{\[]|-?\d(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null))/g;
  let previousStringState = jsonStrToParse;
  jsonStrToParse = jsonStrToParse.replace(fixMissingColonRegex, '$1: ');
  if (previousStringState !== jsonStrToParse) {
      console.warn(`Applied missing colon fix for ${context}.`);
  }
  while (previousStringState !== jsonStrToParse) { // Loop for multiple fixes
      previousStringState = jsonStrToParse;
      jsonStrToParse = jsonStrToParse.replace(fixMissingColonRegex, '$1: ');
      if (previousStringState !== jsonStrToParse) {
          console.warn(`Applied additional missing colon fix for ${context}.`);
      }
  }

  try {
    return JSON.parse(jsonStrToParse) as T;
  } catch (initialError) {
    console.warn(`Initial JSON.parse failed for ${context} (after primary cleanups & colon fix). Error: ${(initialError as Error).message}`);
    console.warn("JSON string at initial failure:", jsonStrToParse);
    console.debug("Full raw text from Gemini (original input to function):", text);

    let currentJsonState = jsonStrToParse;

    // Attempt 1: Fix missing commas between top-level elements (e.g., ], "key" or }, "key" or "value", "key")
    const fixMissingInterElementCommas = /(}|]|\"(?:[^"\\]|\\.)*\"|\d+\.?\d*(?:[eE][+-]?\d+)?|true|false|null)\s+(?=("|\{|\[))/g;
    let cleanedJsonStrAttempt1 = currentJsonState.replace(fixMissingInterElementCommas, '$1, ');
    if (cleanedJsonStrAttempt1 !== currentJsonState) {
        console.warn("Applied missing inter-element comma cleanup (Attempt 1). Cleaned JSON string:", cleanedJsonStrAttempt1);
    } else {
        console.warn("Missing inter-element comma cleanup (Attempt 1) did not change the string.");
    }
    try {
        return JSON.parse(cleanedJsonStrAttempt1) as T;
    } catch (errorAfterAttempt1) {
        console.warn(`JSON.parse failed after Attempt 1 (inter-element commas) for ${context}. Error: ${(errorAfterAttempt1 as Error).message}`);
        currentJsonState = cleanedJsonStrAttempt1;

        // Attempt 2: Remove extraneous text within arrays (e.g., "valid_string" extraneous text , "another_string")
        // Junk pattern [^\]\[}{,:]+? excludes colons to prevent destroying "key": "value" pairs.
        const regexCleanExtraneousText = /("(?:[^"\\]|\\.)*")\s*([^\]\[}{,:]+?)\s*([,\]])/g;
        let cleanedJsonStrAttempt2 = currentJsonState.replace(regexCleanExtraneousText, '$1$3');
        if (cleanedJsonStrAttempt2 !== currentJsonState) {
            console.warn("Applied extraneous text in array cleanup (Attempt 2). Cleaned JSON string:", cleanedJsonStrAttempt2);
        } else {
            console.warn("Extraneous text in array cleanup (Attempt 2) did not change the string.");
        }
        try {
            return JSON.parse(cleanedJsonStrAttempt2) as T;
        } catch (errorAfterAttempt2) {
            console.warn(`JSON.parse failed after Attempt 2 (extraneous text) for ${context}. Error: ${(errorAfterAttempt2 as Error).message}`);
            currentJsonState = cleanedJsonStrAttempt2;

            // Attempt 3: Fix missing commas between string elements in an array (e.g., "string1" "string2")
            const regexAddMissingStringComma = /("(?:[^"\\]|\\.)*")\s+("(?:[^"\\]|\\.)*")/g;
            let cleanedJsonStrAttempt3 = currentJsonState.replace(regexAddMissingStringComma, '$1,$2');
             if (cleanedJsonStrAttempt3 !== currentJsonState) {
                console.warn("Applied missing string comma cleanup (Attempt 3). Further cleaned JSON string:", cleanedJsonStrAttempt3);
            } else {
                 console.warn("Missing string comma cleanup (Attempt 3) did not change the string further.");
            }
            try {
                return JSON.parse(cleanedJsonStrAttempt3) as T;
            } catch (finalError) {
                console.error(`JSON.parse still failed for ${context} after all cleanup attempts. Final error: ${(finalError as Error).message}`);
                console.error("Original problematic raw text from Gemini (that resulted in initial parse failure):", text); 
                console.error("State of JSON string at final failure:", cleanedJsonStrAttempt3);
                throw new Error(`ไม่สามารถประมวลผลข้อมูล JSON จาก Gemini สำหรับ ${context} ได้ แม้หลังจากการพยายามแก้ไข: ${ (finalError as Error).message }`);
            }
        }
    }
  }
};

const normalizeRiskData = (
    rawRisk: RawGeminiDetection,
    imgNaturalWidth: number,
    imgNaturalHeight: number
  ): Omit<DetectedRiskCore, 'id'> => {
  
    const x_min_norm = Math.max(0, Math.min(1, Number(rawRisk.box_2d[0]) || 0));
    const y_min_norm = Math.max(0, Math.min(1, Number(rawRisk.box_2d[1]) || 0));
    const x_max_norm = Math.max(0, Math.min(1, Number(rawRisk.box_2d[2]) || 0));
    const y_max_norm = Math.max(0, Math.min(1, Number(rawRisk.box_2d[3]) || 0));

    const boxX = x_min_norm * imgNaturalWidth;
    const boxY = y_min_norm * imgNaturalHeight;
    const boxWidth = (x_max_norm - x_min_norm) * imgNaturalWidth;
    const boxHeight = (y_max_norm - y_min_norm) * imgNaturalHeight;

    const maskPointsPixel: Array<[number, number]> = rawRisk.mask.map(p => [
      Math.max(0, Math.min(1, Number(p[0]) || 0)) * imgNaturalWidth,
      Math.max(0, Math.min(1, Number(p[1]) || 0)) * imgNaturalHeight
    ]);
  
    return {
      maskPoints: maskPointsPixel,
      boundingBox: [boxX, boxY, boxWidth, boxHeight],
      label: rawRisk.label || "ความเสี่ยงที่ไม่ระบุชื่อ",
    };
};


export const analyzeImageWithGemini = async (base64ImageData: string, modelName: TextModelId): Promise<DetectedRiskCore[]> => {
  const ai = getAiClient(); // Call this first; it throws if API key is misconfigured.

  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg', 
      data: base64ImageData,
    },
  };
  const textPart = { text: GEMINI_IMAGE_ANALYSIS_PROMPT_TEMPLATE };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelName, 
      contents: { parts: [imagePart, textPart] },
      config: { responseMimeType: "application/json" } 
    });

    const rawDetections = parseGeminiJsonResponse<RawGeminiDetectionResponse>(response.text, "การตรวจจับความเสี่ยงเบื้องต้น");

    const img = new Image();
    img.src = `data:image/unknown;base64,${base64ImageData}`; 
    await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = (err) => {
            console.error("Error loading image in service to get dimensions:", err);
            reject(new Error("Could not load image to determine dimensions for risk normalization."));
        };
    });
    const naturalWidth = img.naturalWidth;
    const naturalHeight = img.naturalHeight;

    if (naturalWidth === 0 || naturalHeight === 0) {
        throw new Error("Image dimensions are zero, cannot normalize risk data.");
    }
    
    if (!Array.isArray(rawDetections)) {
        console.warn("Gemini detection response is not an array:", rawDetections);
        return []; 
    }

    return rawDetections.map((rawRisk: RawGeminiDetection) => {
      if (!rawRisk || !Array.isArray(rawRisk.box_2d) || rawRisk.box_2d.length !== 4 || !Array.isArray(rawRisk.mask)) {
        console.warn("Skipping malformed raw risk data:", rawRisk);
        return null; 
      }
      const normalizedData = normalizeRiskData(rawRisk, naturalWidth, naturalHeight);
      return {
        id: crypto.randomUUID(),
        ...normalizedData,
      };
    }).filter(risk => risk !== null) as DetectedRiskCore[]; 

  } catch (error) {
     // If error is already the specific API key configuration error from getAiClient, rethrow it.
    if (error instanceof Error && error.message.startsWith("API_KEY environment variable is not set")) {
        throw error;
    }
    // Otherwise, wrap it as a Gemini communication or processing error.
    console.error("Error in analyzeImageWithGemini (API call or parsing):", error);
    if (error instanceof Error && error.message.includes("Could not load image")) {
         throw error; // Rethrow specific image loading error
    }
    throw new Error(`เกิดข้อผิดพลาดระหว่างการวิเคราะห์ภาพด้วย AI (Gemini): ${ (error as Error).message }`);
  }
};

export const getDetailedRiskAssessmentFromGemini = async (riskLabel: string, base64ImageData: string, modelName: TextModelId): Promise<DetailedAssessment> => {
  const ai = getAiClient(); // Call this first; it throws if API key is misconfigured.

  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64ImageData,
    },
  };
  const textPart = { text: GEMINI_DETAILED_ASSESSMENT_PROMPT_TEMPLATE(riskLabel) };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelName,
      contents: { parts: [imagePart, textPart] },
      config: { responseMimeType: "application/json" }
    });
    
    const rawAssessment = parseGeminiJsonResponse<RawGeminiDetailedResponse>(response.text, `การประเมินความเสี่ยงโดยละเอียดสำหรับ "${riskLabel}"`);

    return {
      severity: Math.max(1, Math.min(5, Number(rawAssessment.severity_score) || 3)),
      likelihood: Math.max(1, Math.min(5, Number(rawAssessment.likelihood_score) || 3)),
      riskLevelDescription: rawAssessment.risk_level_verbal_description || "ไม่มีคำอธิบายระดับความเสี่ยง",
      correctivePreventiveMeasures: Array.isArray(rawAssessment.corrective_preventive_measures) ? rawAssessment.corrective_preventive_measures : [],
      internationalStandards: Array.isArray(rawAssessment.international_standards_references) ? rawAssessment.international_standards_references : [],
      thaiLaws: Array.isArray(rawAssessment.relevant_thai_laws) ? rawAssessment.relevant_thai_laws : [],
      kubotaStandards: Array.isArray(rawAssessment.kubota_standards_references) ? rawAssessment.kubota_standards_references : [],
    };

  } catch (error) {
    // If error is already the specific API key configuration error from getAiClient, rethrow it.
    if (error instanceof Error && error.message.startsWith("API_KEY environment variable is not set")) {
        throw error;
    }
    // Otherwise, wrap it as a Gemini communication or processing error.
    console.error(`Error in getDetailedRiskAssessmentFromGemini for "${riskLabel}" (API call or parsing):`, error);
    throw new Error(`เกิดข้อผิดพลาดในการประเมินความเสี่ยงโดยละเอียดสำหรับ "${riskLabel}" (Gemini): ${ (error as Error).message }`);
  }
};
