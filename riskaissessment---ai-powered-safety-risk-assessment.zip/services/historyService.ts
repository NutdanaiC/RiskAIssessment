
import type { AssessmentRecord } from '../types';

const HISTORY_KEY = 'riskAssessmentHistory_v1'; // Consider versioning if structure changes

export const getAssessmentHistory = (): AssessmentRecord[] => {
  try {
    const historyJson = localStorage.getItem(HISTORY_KEY);
    if (!historyJson) return [];
    
    const parsedHistory = JSON.parse(historyJson) as AssessmentRecord[];
    // Optional: Add validation for each record if needed
    return parsedHistory.filter(record => record && record.id && record.timestamp); // Basic validation
  } catch (error) {
    console.error("Error retrieving assessment history from localStorage:", error);
    localStorage.removeItem(HISTORY_KEY); // Clear corrupted history
    return [];
  }
};

export const saveAssessmentToHistory = (record: AssessmentRecord): void => {
  if (!record || !record.id) {
    console.error("Attempted to save invalid record to history:", record);
    return;
  }
  try {
    const history = getAssessmentHistory();
    const recordExists = history.some(r => r.id === record.id);
    
    let updatedHistory;
    if (recordExists) {
      // Update existing record
      updatedHistory = history.map(r => (r.id === record.id ? record : r));
    } else {
      // Add new record to the beginning
      updatedHistory = [record, ...history];
    }
    
    // Limit history size (e.g., to 50 most recent items)
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory.slice(0, 50)));
  } catch (error) {
    console.error("Error saving assessment to history in localStorage:", error);
    // Potentially notify user or implement more robust error handling if storage is full / quotas exceeded
  }
};

export const deleteAssessmentFromHistory = (id: string): void => {
  if (!id) return;
  try {
    const history = getAssessmentHistory();
    const updatedHistory = history.filter(record => record.id !== id);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
  } catch (error) {
    console.error("Error deleting assessment from history in localStorage:", error);
  }
};

export const updateAssessmentInHistory = (updatedRecord: AssessmentRecord): void => {
  // saveAssessmentToHistory already handles updating if ID exists or adding if new.
  saveAssessmentToHistory(updatedRecord);
};
